CREATE TABLE Dealership (
    DealerID VARCHAR(10) PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Region VARCHAR(50) NOT NULL
);
-- Table: Carrier
CREATE TABLE Carrier (
    CarrierID VARCHAR(10) PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    TransportMode VARCHAR(20) NOT NULL
);
-- Table: Vehicle
CREATE TABLE Vehicle (
    VIN CHAR(17) PRIMARY KEY,
    Model VARCHAR(50) NOT NULL,
    Year INTEGER NOT NULL,
    MSRP NUMERIC(10, 2) NOT NULL,
    TrimLevel VARCHAR(50) NOT NULL,
    Color VARCHAR(30)
);
-- Table: Shipment
CREATE TABLE Shipment (
    ShipmentID VARCHAR(10) PRIMARY KEY,
    DealerID VARCHAR(10) REFERENCES Dealership(DealerID),
    CarrierID VARCHAR(10) REFERENCES Carrier(CarrierID),
    ShipDate DATE NOT NULL,
    ETA DATE NOT NULL,
    ActualArrivalDate DATE 
);

-- Table: ShipmentVehicle 
CREATE TABLE ShipmentVehicle (
    ShipmentID VARCHAR(10) REFERENCES Shipment(ShipmentID),
    VIN CHAR(17) REFERENCES Vehicle(VIN),
    VehicleStatus VARCHAR(50) NOT NULL, 
    PRIMARY KEY (ShipmentID, VIN)
);

-- Table: ShipmentStatus 
CREATE TABLE ShipmentStatus (
    StatusLogID SERIAL PRIMARY KEY,
    ShipmentID VARCHAR(10) REFERENCES Shipment(ShipmentID),
    "Timestamp" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    StatusType VARCHAR(50) NOT NULL,
    LocationDetails VARCHAR(255)
);

--Altering table according to the capacities
ALTER TABLE Vehicle
ALTER COLUMN VIN TYPE VARCHAR(50);

ALTER TABLE ShipmentVehicle
ALTER COLUMN VIN TYPE VARCHAR(50);


