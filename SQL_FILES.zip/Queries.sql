
--1Retrieve the VIN, Model, Year, MSRP, and TrimLevel for all high-value 2025 model vehicles
 --(MSRP greater than $50,000).
SELECT
 VIN,
 Model,
 Year,
 MSRP,
 TrimLevel
 FROM Vehicle
 WHERE MSRP > 50000 AND Year = 2025
 ORDER BY MSRP DESC;

 --2 List the names of the carrier, vehicle model, and color for all cars currently ’En Route’ to
 --the dealership named ’West Coast Imports’.
 SELECT
 D.Name AS DealershipName,
 C.Name AS CarrierName,
 V.Model,
 V.Color,
 SV.VehicleStatus
 FROM ShipmentVehicle AS SV
 INNER JOIN Shipment AS S ON SV.ShipmentID = S.ShipmentID
 INNER JOIN Vehicle AS V ON SV.VIN = V.VIN
 INNER JOIN Dealership AS D ON S.DealerID = D.DealerID
 INNER JOIN Carrier AS C ON S.CarrierID = C.CarrierID
 WHERE D.Name = 'West Coast Imports' AND SV.VehicleStatus = 'En Route';

 --3 Calculate the total MSRP value of vehicles for each shipment.
  SELECT
 SV.ShipmentID,
 S.ShipDate,
 SUM(V.MSRP) AS TotalShipmentValue
 FROM ShipmentVehicle AS SV
 INNER JOIN Vehicle AS V ON SV.VIN = V.VIN
 INNER JOIN Shipment AS S ON SV.ShipmentID = S.ShipmentID
 GROUP BY SV.ShipmentID, S.ShipDate
 ORDER BY TotalShipmentValue DESC;

 --4Find the ID, name, and region of dealerships that have used a ’Rail’ transport mode for
 --any shipment.
  SELECT
 D.DealerID,
 D.Name,
 D.Region
 FROM Dealership AS D
 WHERE EXISTS (
 SELECT 1
 FROM Shipment AS S
 INNER JOIN Carrier AS C ON S.CarrierID = C.CarrierID
 WHERE S.DealerID = D.DealerID
 AND C.TransportMode = 'Rail'
 );

 --5 Find the unique VIN, Model, Year, and TrimLevel of all vehicles that were manufactured in
 --2025 ORhave the ’Denali Ultimate’ trim level.
 SELECT VIN, Model, Year, TrimLevel FROM Vehicle WHERE Year = 2025
 UNION
 SELECT VIN, Model, Year, TrimLevel FROM Vehicle WHERE TrimLevel = 'Denali Ultimate'
 ORDER BY Year DESC, Model ASC;

 --6 Increase the MSRP of all ’Sport Touring’ trim vehicles by 5% in a controlled transaction.
 --This demonstrates the use of BEGIN TRANSACTION and the option to either COMMIT or ROLLBACK.
  BEGIN TRANSACTION;
 UPDATE Vehicle
 SET MSRP = ROUND(MSRP * 1.05, 2)
 WHERE TrimLevel = 'Sport Touring';

 --7 Create a view (Late_Shipments_Detail) to quickly query shipments that arrived after their
 --Estimated Time of Arrival (ETA), and create an index to optimize filtering on the Dealership re
--gion.
  CREATE VIEW Late_Shipments_Detail AS
 SELECT
 ShipmentID,
 DealerID,
 ShipDate,
 ETA,
 ActualArrivalDate,
 (ActualArrivalDate- ETA) AS DaysLate
 FROM Shipment
 WHERE ActualArrivalDate IS NOT NULL AND ActualArrivalDate > ETA;-- Create an index to speed up lookups/filtering on the Region column
 CREATE INDEX IX_Dealership_Region ON Dealership (Region);

 --8 Create a trigger that automatically logs an event in the ShipmentStatus table whenever a
 --vehicle’s status in the ShipmentVehicle table is updated to ’Received’.
 -- Step A: Create the function (The Logic)
CREATE OR REPLACE FUNCTION log_receipt_update_func()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO ShipmentStatus (ShipmentID, Timestamp, StatusType, LocationDetails)
    VALUES (NEW.ShipmentID, CURRENT_TIMESTAMP, 'VEHICLE RECEIVED', 'Vehicle check-in confirmed.');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_log_receipt_update ON ShipmentVehicle;

CREATE TRIGGER trg_log_receipt_update
AFTER UPDATE ON ShipmentVehicle
FOR EACH ROW
WHEN (OLD.VehicleStatus IS DISTINCT FROM 'Received' AND NEW.VehicleStatus = 'Received')
EXECUTE FUNCTION log_receipt_update_func();

 -- 9. Total shipments per dealership per month 
WITH MonthlyShipmentCounts AS (
    SELECT
        DealerID,
     
        TO_CHAR(ShipDate, 'YYYY-MM') AS ShipmentMonth, 
        COUNT(ShipmentID) AS TotalShipments
    FROM Shipment
    GROUP BY DealerID, TO_CHAR(ShipDate, 'YYYY-MM')
)
SELECT
    D.Name AS DealershipName,
    MSC.ShipmentMonth,
    MSC.TotalShipments
FROM MonthlyShipmentCounts AS MSC
INNER JOIN Dealership AS D ON MSC.DealerID = D.DealerID
ORDER BY MSC.ShipmentMonth DESC, MSC.TotalShipments DESC;


 --10 Identify the single most expensive vehicle(highestMSRP) for each distinct vehicle model
 --using a WindowFunction to rank them
  WITH RankedVehicles AS (
  SELECT
  VIN,
  Model,
  MSRP,
  ROW_NUMBER() OVER (PARTITION BY Model ORDER BY MSRP DESC) as rn
  FROM Vehicle
   )
 SELECT
 VIN,

 Model,
 MSRP
 FROM RankedVehicles
 WHERE rn = 1
 ORDER BY Model ASC;

 -- VIEWS, INDEX, AND TRIGGER
-- 1. View Creation
CREATE OR REPLACE VIEW Late_Shipments_Detail AS
SELECT
    ShipmentID,
    DealerID,
    ShipDate,
    ETA,
    ActualArrivalDate,
    (ActualArrivalDate - ETA) AS DaysLate
FROM Shipment
WHERE ActualArrivalDate IS NOT NULL AND ActualArrivalDate > ETA;

-- 2. Index Creation
DROP INDEX IF EXISTS IX_Dealership_Region;
CREATE INDEX IX_Dealership_Region ON Dealership (Region);

-- 3. Trigger Function

CREATE OR REPLACE FUNCTION log_receipt_update()
RETURNS TRIGGER AS $trigger_body$
BEGIN
    INSERT INTO ShipmentStatus (ShipmentID, Timestamp, StatusType, LocationDetails)
    VALUES (NEW.ShipmentID, CURRENT_TIMESTAMP, 'VEHICLE RECEIVED', 'Vehicle check-in confirmed.');
    
    RETURN NEW;
END;
$trigger_body$ LANGUAGE plpgsql;

-- 4. Trigger Definition

DROP TRIGGER IF EXISTS trg_log_receipt_update ON ShipmentVehicle;

CREATE TRIGGER trg_log_receipt_update
AFTER UPDATE ON ShipmentVehicle
FOR EACH ROW
WHEN (OLD.VehicleStatus IS DISTINCT FROM 'Received' AND NEW.VehicleStatus = 'Received')
EXECUTE FUNCTION log_receipt_update();


 